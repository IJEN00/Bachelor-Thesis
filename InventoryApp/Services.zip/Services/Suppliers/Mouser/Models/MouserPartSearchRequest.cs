﻿namespace InventoryApp.Services.Suppliers.Mouser.Models
{
    public class MouserPartSearchRequest
    {
        public string MouserPartNumber { get; set; } = string.Empty;
        public string PartSearchOptions { get; set; } = "string"; 
    }
}
