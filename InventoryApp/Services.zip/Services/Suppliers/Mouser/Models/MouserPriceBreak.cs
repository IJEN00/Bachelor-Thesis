﻿namespace InventoryApp.Services.Suppliers.Mouser.Models
{
    public class MouserPriceBreak
    {
        public int Quantity { get; set; }
        public string Price { get; set; } = string.Empty;
    }
}
