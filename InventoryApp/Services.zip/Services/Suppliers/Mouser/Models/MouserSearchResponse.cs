﻿namespace InventoryApp.Services.Suppliers.Mouser.Models
{
    public class MouserSearchResponse
    {
        public MouserSearchResults SearchResults { get; set; } = new();
    }
}
