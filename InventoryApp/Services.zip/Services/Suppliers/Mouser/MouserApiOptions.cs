﻿namespace InventoryApp.Services.Suppliers.Mouser
{
    public class MouserApiOptions
    {
        public string BaseUrl { get; set; } = string.Empty;
        public string ApiKey { get; set; } = string.Empty;
    }
}
